# Browser test with a FAKE backend. Run: python3 tests/frontend.test.py  (needs playwright)
import json,re,sys,os,subprocess,time
from playwright.sync_api import sync_playwright
srv=subprocess.Popen([sys.executable,'-m','http.server','8765','--bind','127.0.0.1'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
F='http://127.0.0.1:8765/index.html'
bad=0
def ok(n,c,d=''):
    global bad
    print(('PASS ' if c else 'FAIL ')+n,d)
    if not c: bad+=1
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':800})
    pg.route('**/fonts.*/**',lambda r:r.abort())
    reqs=[];mode={'v':'ok'}
    def h(r):
        reqs.append((r.request.url.split('/')[-1],json.loads(r.request.post_data or '{}')))
        if mode['v']=='abort': return r.abort()
        if mode['v']=='fail': return r.fulfill(status=502,content_type='application/json',body='{"ok":false,"error":"klaviyo_rejected"}')
        r.fulfill(status=200,content_type='application/json',body='{"ok":true,"accepted":true}')
    pg.route('**/.netlify/functions/**',h)
    pg.goto(F);pg.wait_for_timeout(300)
    # newsletter
    pg.fill('#nle','a@b.com');pg.click('#nl button');pg.wait_for_timeout(100)
    ok('newsletter needs consent, sends nothing','tick the box' in pg.inner_text('#nlm') and not reqs)
    pg.fill('#nle','a@b.com');pg.check('#nlc');pg.click('#nl button');pg.wait_for_timeout(200)
    ok('signup sent once with consent',reqs==[('subscribe',{'email':'a@b.com','consent':True})],str(reqs))
    ok('success msg is cautious','accepted the request' in pg.inner_text('#nlm'),pg.inner_text('#nlm'))
    ok('subscriber status klaviyo_accepted',pg.evaluate("JSON.parse(localStorage.ch_demo_subscribers)[0].status")=='klaviyo_accepted')
    # events with known email
    reqs.clear();pg.evaluate("location.hash='meal-yam'");pg.wait_for_timeout(150)
    ok('product view event',reqs and reqs[0][0]=='track' and reqs[0][1]['action']=='viewed_product' and reqs[0][1]['mealId']=='yam',str(reqs))
    reqs.clear();pg.click('[data-add]');pg.wait_for_timeout(150)
    ok('add to cart event with cart lines',reqs and reqs[0][1]['action']=='added_to_cart' and reqs[0][1]['cart']==[{'id':'yam','qty':1}],str(reqs))
    # checkout
    reqs.clear();pg.evaluate("location.hash='checkout'");pg.wait_for_timeout(100)
    pg.fill('#n','Ada Obi');pg.fill('#e','ada@real.com');pg.fill('#p','08031234567');pg.fill('#a','12 Marian Road Calabar')
    pg.press('#a','Tab');pg.wait_for_timeout(150)
    ok('checkout started once',[r[1]['action'] for r in reqs]==['started_checkout'],str(reqs))
    pg.click('#co button');pg.wait_for_timeout(300)
    o=[r for r in reqs if r[1]['action']=='placed_order']
    ok('one placed_order, no prices from browser',len(o)==1 and 'price' not in json.dumps(o[0][1]) and re.match(r'CH-TEST-[A-Z0-9]{8}$',o[0][1]['orderRef']),str(o))
    ok('order screen shows cautious Klaviyo status','accepted the test order' in pg.inner_text('#kst'),pg.inner_text('#kst'))
    ok('order record marked accepted',pg.evaluate("JSON.parse(localStorage.ch_demo_orders)[0].klaviyo")=='accepted')
    # invalid checkout sends no order
    reqs.clear();pg.evaluate("location.hash='menu'");pg.wait_for_timeout(80);pg.click('[data-add]');pg.evaluate("location.hash='checkout'");pg.wait_for_timeout(80)
    pg.click('#co button');pg.wait_for_timeout(150)
    ok('invalid checkout sends no placed_order',not [r for r in reqs if r[1].get('action')=='placed_order'])
    # failure honesty
    mode['v']='fail';reqs.clear();pg.evaluate("location.hash='home'");pg.wait_for_timeout(80)
    pg.fill('#nle','c@d.com');pg.check('#nlc');pg.click('#nl button');pg.wait_for_timeout(200)
    ok('Klaviyo failure not shown as success','did not confirm' in pg.inner_text('#nlm') and 'klaviyo_rejected' in pg.inner_text('#nlm'),pg.inner_text('#nlm'))
    ok('failed subscriber flagged',pg.evaluate("JSON.parse(localStorage.ch_demo_subscribers).find(s=>s.email=='c@d.com').status")=='klaviyo_failed')
    mode['v']='abort';pg.fill('#nle','e@f.com');pg.check('#nlc');pg.click('#nl button');pg.wait_for_timeout(200)
    ok('unreachable backend handled','backend_unreachable' in pg.inner_text('#nlm'),pg.inner_text('#nlm'))
    # no events for unknown visitor
    mode['v']='ok';pg.evaluate("localStorage.removeItem('ch_email')");reqs.clear()
    pg.evaluate("location.hash='meal-pasta'");pg.wait_for_timeout(100);pg.evaluate("location.hash='menu'");pg.wait_for_timeout(80);pg.click('[data-add]');pg.wait_for_timeout(100)
    ok('anonymous visitor: no view/cart events',not reqs,str(reqs))
    b.close()
src=open('index.html').read().split('<script>')[1]
ok('no private key patterns in browser code',not re.search(r'pk_[A-Za-z0-9]{6,}|Klaviyo-API-Key|KLAVIYO_API',src))
srv.terminate()
sys.exit(1 if bad else 0)
