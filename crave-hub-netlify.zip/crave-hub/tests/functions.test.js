// Offline tests with a fake Klaviyo. Run: node tests/functions.test.js
// These prove OUR code builds correct requests and handles errors. They do NOT prove Klaviyo accepts them: use klaviyo-test for that.
const assert = require("assert");
let calls = [], reply = { status: 202, body: "" }, logs = [];
global.fetch = async (url, opt) => { calls.push({ url, opt, body: opt.body ? JSON.parse(opt.body) : null });
  return { ok: reply.status < 300, status: reply.status, text: async () => reply.body, headers: { get: () => "req-1" } }; };
const origLog = console.log; console.log = (...a) => logs.push(a.join(" ")); console.error = (...a) => logs.push(a.join(" "));
const track = require("../netlify/functions/track").handler, sub = require("../netlify/functions/subscribe").handler, tst = require("../netlify/functions/klaviyo-test").handler;
const KEY = "pk_SECRET_KEY_123";
const ev = (b, m = "POST", h = {}) => ({ httpMethod: m, headers: h, body: JSON.stringify(b), queryStringParameters: b });
let pass = 0; const t = async (n, f) => { calls = []; try { await f(); pass++; origLog("PASS", n); } catch (e) { origLog("FAIL", n, e.message); process.exitCode = 1; } };
const set = (o) => { for (const k of ["KLAVIYO_ENV", "KLAVIYO_API_KEY_DEMO", "KLAVIYO_API_KEY_PROD", "KLAVIYO_LIST_ID_DEMO", "ALLOWED_ORIGIN", "TEST_TOKEN"]) delete process.env[k]; Object.assign(process.env, o); };
const body = (r) => JSON.parse(r.body);
const goodCart = [{ id: "jollof", qty: 2 }, { id: "yam", qty: 1 }];

(async () => {
  set({});
  await t("no key -> 503, no Klaviyo call", async () => { const r = await track(ev({ action: "viewed_product", email: "a@b.com", mealId: "yam" })); assert.equal(r.statusCode, 503); assert.equal(calls.length, 0); });
  set({ KLAVIYO_API_KEY_DEMO: KEY, KLAVIYO_LIST_ID_DEMO: "LIST1" });
  await t("bad env value -> 500", async () => { process.env.KLAVIYO_ENV = "staging"; const r = await track(ev({})); assert.equal(r.statusCode, 500); delete process.env.KLAVIYO_ENV; });
  await t("GET to track -> 405", async () => assert.equal((await track(ev({}, "GET"))).statusCode, 405));
  await t("invalid JSON -> 400", async () => assert.equal((await track({ httpMethod: "POST", headers: {}, body: "{bad" })).statusCode, 400));
  await t("oversize body -> 413", async () => assert.equal((await track({ httpMethod: "POST", headers: {}, body: "x".repeat(10001) })).statusCode, 413));
  await t("wrong origin -> 403", async () => { process.env.ALLOWED_ORIGIN = "https://crave.netlify.app"; const r = await track(ev({}, "POST", { origin: "https://evil.com" })); assert.equal(r.statusCode, 403); delete process.env.ALLOWED_ORIGIN; });
  await t("invalid email -> 400, no call", async () => { const r = await track(ev({ action: "viewed_product", email: "nope", mealId: "yam" })); assert.equal(r.statusCode, 400); assert.equal(calls.length, 0); });
  await t("unknown action / meal rejected", async () => { assert.equal((await track(ev({ action: "x", email: "a@b.com" }))).statusCode, 400); assert.equal((await track(ev({ action: "viewed_product", email: "a@b.com", mealId: "pizza" }))).statusCode, 400); });
  await t("viewed_product payload correct", async () => {
    const r = await track(ev({ action: "viewed_product", email: "A@B.com", mealId: "yam" })); assert.equal(r.statusCode, 200);
    const c = calls[0]; assert.equal(c.url, "https://a.klaviyo.com/api/events"); assert.equal(c.opt.method, "POST");
    assert.equal(c.opt.headers.revision, "2026-10-15"); assert.equal(c.opt.headers.Authorization, "Klaviyo-API-Key " + KEY);
    const a = c.body.data.attributes; assert.equal(a.metric.data.attributes.name, "Viewed Product"); assert.equal(a.profile.data.attributes.email, "a@b.com");
    assert.equal(a.properties.test, true); assert.equal(a.properties.environment, "demo"); assert.equal(a.value, 3500); assert.ok(a.unique_id); });
  await t("added_to_cart uses SERVER prices, ignores client prices", async () => {
    await track(ev({ action: "added_to_cart", email: "a@b.com", mealId: "jollof", cart: [{ id: "jollof", qty: 2, price: 1 }, { id: "yam", qty: 1 }] }));
    assert.equal(calls[0].body.data.attributes.value, 12500); });
  await t("bad carts rejected", async () => { for (const cart of [[], [{ id: "x", qty: 1 }], [{ id: "yam", qty: 0 }], [{ id: "yam", qty: 99 }], "str", null]) assert.equal((await track(ev({ action: "started_checkout", email: "a@b.com", cart }))).statusCode, 400); assert.equal(calls.length, 0); });
  await t("placed_order demo ok: unique_id=ref, total incl delivery, name split", async () => {
    const r = await track(ev({ action: "placed_order", email: "a@b.com", name: "Ada  Obi Eze", orderRef: "CH-TEST-AB12CD34", items: goodCart })); assert.equal(r.statusCode, 200);
    const a = calls[0].body.data.attributes; assert.equal(a.unique_id, "CH-TEST-AB12CD34"); assert.equal(a.value, 13500); assert.equal(a.value_currency, "NGN");
    assert.equal(a.profile.data.attributes.first_name, "Ada"); assert.equal(a.profile.data.attributes.last_name, "Obi Eze"); assert.equal(a.properties.test, true); });
  await t("placed_order rejects non-test refs", async () => { for (const ref of ["", "ORDER-1", "CH-TEST-abc", "CH-REAL-AB12CD34"]) assert.equal((await track(ev({ action: "placed_order", email: "a@b.com", orderRef: ref, items: goodCart }))).statusCode, 400); assert.equal(calls.length, 0); });
  await t("placed_order blocked in production", async () => { set({ KLAVIYO_ENV: "production", KLAVIYO_API_KEY_PROD: KEY }); const r = await track(ev({ action: "placed_order", email: "a@b.com", orderRef: "CH-TEST-AB12CD34", items: goodCart })); assert.equal(r.statusCode, 501); assert.equal(calls.length, 0); set({ KLAVIYO_API_KEY_DEMO: KEY, KLAVIYO_LIST_ID_DEMO: "LIST1" }); });
  await t("production uses PROD key and test=false", async () => { set({ KLAVIYO_ENV: "production", KLAVIYO_API_KEY_PROD: "pk_PROD", KLAVIYO_API_KEY_DEMO: KEY }); await track(ev({ action: "viewed_product", email: "a@b.com", mealId: "yam" })); assert.equal(calls[0].opt.headers.Authorization, "Klaviyo-API-Key pk_PROD"); assert.equal(calls[0].body.data.attributes.properties.test, false); set({ KLAVIYO_API_KEY_DEMO: KEY, KLAVIYO_LIST_ID_DEMO: "LIST1" }); });
  await t("Klaviyo 400/500 -> not reported as success", async () => { for (const s of [400, 401, 429, 500]) { reply = { status: s, body: JSON.stringify({ errors: [{ code: "invalid" }] }) }; const r = await track(ev({ action: "viewed_product", email: "a@b.com", mealId: "yam" })); assert.equal(r.statusCode, 502); assert.equal(body(r).ok, false); } reply = { status: 202, body: "" }; });
  await t("network failure -> 502 not success", async () => { const f = global.fetch; global.fetch = async () => { throw new Error("boom"); }; const r = await track(ev({ action: "viewed_product", email: "a@b.com", mealId: "yam" })); assert.equal(r.statusCode, 502); global.fetch = f; });
  await t("subscribe requires consent === true", async () => { for (const c of [undefined, false, "true", 1]) assert.equal((await sub(ev({ email: "a@b.com", consent: c }))).statusCode, 400); assert.equal(calls.length, 0); });
  await t("subscribe needs list id", async () => { delete process.env.KLAVIYO_LIST_ID_DEMO; assert.equal((await sub(ev({ email: "a@b.com", consent: true }))).statusCode, 503); process.env.KLAVIYO_LIST_ID_DEMO = "LIST1"; });
  await t("subscribe payload correct", async () => {
    const r = await sub(ev({ email: "a@b.com", consent: true })); assert.equal(r.statusCode, 200); const c = calls[0];
    assert.equal(c.url, "https://a.klaviyo.com/api/profile-subscription-bulk-create-jobs"); const d = c.body.data;
    assert.equal(d.type, "profile-subscription-bulk-create-job"); assert.equal(d.relationships.list.data.id, "LIST1");
    assert.equal(d.attributes.profiles.data[0].attributes.subscriptions.email.marketing.consent, "SUBSCRIBED");
    assert.ok(d.attributes.profiles.data[0].attributes.subscriptions.email.marketing.consented_at); assert.ok(!JSON.stringify(d).includes("historical_import")); });
  await t("test tool disabled without TEST_TOKEN, protected with it", async () => {
    assert.equal((await tst(ev({ step: "send", email: "a@b.com", token: "x" }, "GET"))).statusCode, 404); process.env.TEST_TOKEN = "secret123";
    assert.equal((await tst(ev({ step: "send", email: "a@b.com", token: "wrong" }, "GET"))).statusCode, 401); assert.equal(calls.length, 0); });
  await t("test send returns testId, warns on example.com, never claims ingestion", async () => {
    const r = await tst(ev({ step: "send", email: "a@example.com", token: "secret123" }, "GET")); const b = body(r);
    assert.ok(/^TEST-/.test(b.testId)); assert.ok(b.warning); assert.equal(b.eventFound, undefined); });
  await t("test check reports found / not found honestly", async () => {
    const id = "TEST-" + "0".repeat(8) + "-" + "0".repeat(4) + "-" + "0".repeat(4) + "-" + "0".repeat(4) + "-" + "0".repeat(12); let n = 0;
    global.fetch = async () => { n++; const d = n === 1 ? { data: [{ id: "P1" }] } : { data: [{ attributes: { event_properties: { test_id: "other" } } }] };
      return { ok: true, status: 200, text: async () => JSON.stringify(d), headers: { get: () => "r" } }; };
    let b = body(await tst(ev({ step: "check", email: "a@b.com", token: "secret123", testId: id }, "GET"))); assert.equal(b.profileFound, true); assert.equal(b.eventFound, false);
    n = 0; global.fetch = async () => { n++; const d = n === 1 ? { data: [{ id: "P1" }] } : { data: [{ attributes: { event_properties: { test_id: id } } }] };
      return { ok: true, status: 200, text: async () => JSON.stringify(d), headers: { get: () => "r" } }; };
    b = body(await tst(ev({ step: "check", email: "a@b.com", token: "secret123", testId: id }, "GET"))); assert.equal(b.eventFound, true); });
  await t("no secrets or full emails in logs or responses", async () => { const all = logs.join("\n"); assert.ok(!all.includes(KEY)); assert.ok(!all.includes("a@b.com")); assert.ok(!all.includes("secret123")); });
  origLog(pass + " passed" + (process.exitCode ? ", SOME FAILED" : ""));
})();
